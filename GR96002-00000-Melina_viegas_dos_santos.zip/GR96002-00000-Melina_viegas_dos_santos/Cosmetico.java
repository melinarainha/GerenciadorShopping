public class Cosmetico extends Loja {
    private double taxaComercializacao;
    
public Cosmetico (String nome, int quantidadeFuncionarios, double salarioBaseFuncionario, Endereco endereco, Data dataDaFundacao, double taxacomercializacao, int quantidadeMaxima) {
    super(nome, quantidadeFuncionarios, salarioBaseFuncionario, endereco, dataDaFundacao, quantidadeMaxima);
    this.taxaComercializacao = taxaComercializacao;
}

public double getTaxaComercializacao () {
    return taxaComercializacao;
}

public void setTaxaComercializacao (double taxaComercializacao) {
    this.taxaComercializacao = taxaComercializacao;
}

public String toString() {
    return "Loja{:Nome"+getNome()+
           "\nQuantidade de Funcionários:"+getQuantidadeFuncionarios()+
           "\nSalário Base:"+getSalarioBaseFuncionario()+
           "\nEndereço:"+getEndereco()+
           "\nData da Fundação:"+getDataFundacao()+
           "\nTaxa de Comercialização:"+taxaComercializacao+"}";
}
}