public class Alimentacao extends Loja {
    private Data dataAlvara;
    
public Alimentacao (String nome, int quantidadeFuncionarios, double salarioBaseFuncionario, Endereco endereco, Data dataFundacao, Data dataAlvara, int quantidadeMaxima) {
    super(nome, quantidadeFuncionarios, salarioBaseFuncionario, endereco, dataFundacao, quantidadeMaxima);
    this.dataAlvara = dataAlvara;
}

public Data getDataAlvara () {
    return dataAlvara;
}

public void setDataAlvara (Data dataAlvara) {
    this.dataAlvara = dataAlvara;
}

public String toString() {
    return "Loja{:Nome"+getNome()+
           "\nQuantidade de Funcionários:"+getQuantidadeFuncionarios()+
           "\nSalário Base:"+getSalarioBaseFuncionario()+
           "\nEndereço:"+getEndereco()+
           "\nData da Fundação:"+getDataFundacao()+
           "\nData do alvará:"+dataAlvara+"}";
}
}