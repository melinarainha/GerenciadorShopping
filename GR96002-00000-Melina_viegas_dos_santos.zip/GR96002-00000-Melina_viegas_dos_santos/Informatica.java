public class Informatica extends Loja {
    private double seguroEletronicos;
    
public Informatica (String nome, int quantidadeFuncionarios, double salarioBaseFuncionario, Endereco endereco, Data dataFundacao, double seguroEletronicos, int quantidadeMaxima) {
    super(nome, quantidadeFuncionarios, salarioBaseFuncionario, endereco, dataFundacao, quantidadeMaxima);
    this.seguroEletronicos = seguroEletronicos;
}

public double getSeguroEletronicos () {
    return seguroEletronicos;
}

public void setSeguroEletronicos (double seguroEletronicos) {
    this.seguroEletronicos = seguroEletronicos;
}

public String toString() {
    return "Loja{:Nome"+getNome()+
           "\nQuantidade de Funcionários:"+getQuantidadeFuncionarios()+
           "\nSalário Base:"+getSalarioBaseFuncionario()+
           "\nEndereço:"+getEndereco()+
           "\nData da Fundação:"+getDataFundacao()+
           "\nValor do seguro:"+seguroEletronicos+"}";
}
}