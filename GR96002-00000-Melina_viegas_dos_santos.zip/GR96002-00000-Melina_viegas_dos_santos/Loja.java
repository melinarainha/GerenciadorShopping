public class Loja{
    private String nome;
    private int quantidadeFuncionarios;
    private double salarioBaseFuncionario;
    private Endereco endereco;
    private Data dataFundacao;
    private Produto [] estoqueProdutos;
    private int quantidadeAtualProdutos;

public Loja (String nome, int quantidadeFuncionarios, double salarioBaseFuncionario, Endereco endereco, Data dataFundacao, int quantidadeMaxima){
    this.nome = nome;
    this.quantidadeFuncionarios = quantidadeFuncionarios;
    this.salarioBaseFuncionario = salarioBaseFuncionario;
    this.endereco = endereco;
    this.dataFundacao = dataFundacao;
    this.estoqueProdutos = new Produto [quantidadeMaxima];
}

public Loja (String nome, int quantidadeFuncionarios, Endereco endereco, Data dataFundacao, int quantidadeMaxima){
    this.nome = nome;
    this.quantidadeFuncionarios = quantidadeFuncionarios;
    this.salarioBaseFuncionario = -1;
    this.endereco = endereco;
    this.dataFundacao = dataFundacao;
    this.estoqueProdutos = new Produto [quantidadeMaxima];
}

public String getNome () {
    return nome;
}

public int getQuantidadeFuncionarios () {
    return quantidadeFuncionarios;
}

public double getSalarioBaseFuncionario () {
    return salarioBaseFuncionario;
}

public Endereco getEndereco () {
    return endereco;
}

public Data getDataFundacao () {
    return dataFundacao;
}

public Produto [] getEstoqueProdutos () {
    return estoqueProdutos;
}

public void setNome (String nome) {
    this.nome = nome;
}

public void setQuantidadeFuncionarios (int quantidadeFuncionarios) {
    this.quantidadeFuncionarios = quantidadeFuncionarios;
}

public void setSalarioBaseFuncionario (double salarioBaseFuncionario) {
    this.salarioBaseFuncionario = salarioBaseFuncionario;
}

public void setEndereco (Endereco endereco){
    this.endereco = endereco;
}

public void setDataFundacao (Data dataFundacao){
    this.dataFundacao = dataFundacao;
}

public void setEstoqueProdutos (Produto [] estoqueProdutos) {
    this.estoqueProdutos = estoqueProdutos;
}

public double gastosComSalario (){
    if (salarioBaseFuncionario == -1){
        return -1;
    } else {
        return salarioBaseFuncionario * quantidadeFuncionarios;
    }
  }
  
public char tamanhoDaLoja (){
    if (quantidadeFuncionarios < 10){
        return 'P';
    }else if (quantidadeFuncionarios >= 10 && quantidadeFuncionarios <= 30){
        return 'M';
    }else {
        return 'G';
    }
}    

public void imprimeProdutos (){
    System.out.println("Produtos:"+estoqueProdutos);
}

public boolean insereProduto (Produto produto) {
    if(quantidadeAtualProdutos < estoqueProdutos.length) {
        estoqueProdutos[quantidadeAtualProdutos] = produto;
        quantidadeAtualProdutos++;
        return true;
    }else{
        return false; 
    }
}

public boolean removeProduto (String produto) {
    for(int i = 0; i< quantidadeAtualProdutos; i++) {
        if(estoqueProdutos != null && estoqueProdutos[i].getNome().equals(produto)) {
           estoqueProdutos[i] = null;
           for(int j=i; j<quantidadeAtualProdutos -1; j++) {
               estoqueProdutos[j] = estoqueProdutos[j+1];
           }
           estoqueProdutos[quantidadeAtualProdutos - 1] = null;
           quantidadeAtualProdutos--;
           return true;
    }  
}   return false;
}


public String toString() {
    return "Loja{:Nome"+nome+
           "\nQuantidade de Funcionários:"+quantidadeFuncionarios+
           "\nSalário Base:"+salarioBaseFuncionario+
           "\nEndereço:"+endereco+
           "\nData da Fundação:"+dataFundacao+
           "\nEstoque de Produtos:"+estoqueProdutos+"}";
}
}

