public class Data {
    private int dia;
    private int mes;
    private int ano;
    
public Data (int dia, int mes, int ano){
    if (dataValida(dia,mes,ano)){
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }else{
        System.out.println("erro");
        this.dia = 1;
        this.mes = 1;
        this.ano = 2000;
   }
}

public boolean dataValida (int dia, int mes, int ano){
    if ( mes<1 || mes>12){
        return false;
    }
    int [] dias = diasNoMes(ano);
        return dia >=1 && dia <= dias[mes-1];
}

public boolean verificaAnoBissexto (){
    if (ano % 400 == 0){
        return true;
    }else if (ano % 100 == 0){
        return false;
    }else if (ano % 4 == 0){
        return true;
    }else{
        return false;
    }
}

public int [] diasNoMes (int ano){
    if (verificaAnoBissexto()){
        return new int []{31,29,31,30,31,30,31,31,30,31,30};
    }else{
        return new int []{31,28,31,30,31,30,31,31,30,31,30};
    }
}

public int getDia (){
    return dia;
}

public int getMes (){
    return mes;
}

public int getAno (){
    return ano;
}

public void setDia (int dia){
    this.dia = dia;
}

public void setMes (int mes){
    this.mes = mes;
}

public void setAno (int ano){
    this.ano = ano;
}

public String toString(){
    return "Data{:"+dia+"/"+mes+"/"+ano+"}";
}

public int compara (Data outra) {
    if (this.ano != outra.ano) {
        return this.ano - outra.ano;
    }else if (this.mes != outra.mes) {
        return this.mes - outra.mes;
    }else {
        return this.dia - outra.dia;
    }
}
}