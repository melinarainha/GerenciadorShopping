public class Produto {
    private String nome;
    private double preco;
    private Data dataValidade;

public Produto ( String nome, double preco, Data dataDeValidade) {
    this.nome = nome;
    this.preco = preco;
    this.dataValidade = dataValidade;
}

public String getNome () {
    return nome;
}

public double getPreco () {
    return preco;
}

public Data getDataValidade () {
    return dataValidade;
}

public void setNome (String nome){
    this.nome = nome;
}

public void setPreco (double preco) {
    this.preco = preco;
}

public void setDataValidade (Data dataValidade) {
    this.dataValidade = dataValidade;
}

public String toString (){
    return "Produto {Nome:"+nome+", Preço:R$"+preco+"Data de Validade:"+dataValidade+"}";
}

public boolean estaVencido (Data dataValida) {
    if (dataValidade.compara(dataValida)<0){
        return true;
    }else{
        return false;
    }
}
}
