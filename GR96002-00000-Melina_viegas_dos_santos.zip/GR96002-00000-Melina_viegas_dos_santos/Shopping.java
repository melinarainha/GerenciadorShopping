public class Shopping {
    
    private String nome;
    private Endereco endereco;
    private Loja [] lojas;
    private int quantidadeLojas;

public Shopping (String nome, Endereco endereco, int quantidadeMaxima) {
    this.nome = nome;
    this.endereco = endereco;
    this.lojas = new Loja [quantidadeMaxima];
    this.quantidadeLojas = 0;
}
    
public String getNome () {
    return  nome;
}

public Endereco getEndereco () {
    return endereco;
}

public Loja [] getLojas () {
    return lojas; 
}

public void setNome (String nome) {
    this.nome = nome;
}

public void setEndereco (Endereco endereco) {
    this.endereco = endereco;
}

public void setLojas (Loja [] lojas) {
    this.lojas = lojas;
}

public boolean insereLoja (Loja loja) {
    if(quantidadeLojas < lojas.length) {
        lojas[quantidadeLojas] = loja;
        quantidadeLojas ++;
        return true;
    } 
        return false;
}


public boolean removeLoja (String loja) {
    if (lojas == null || quantidadeLojas == 0) {
        return false;
    }
    for(int i = 0; i< quantidadeLojas; i++) {
        if(lojas[i] != null && lojas[i].getNome().equals(loja)) {
           lojas[i] = null;
           for(int j=i; j<quantidadeLojas -1; j++) {
               lojas[j] = lojas[j+1];
           }
           lojas[quantidadeLojas - 1] = null;
           quantidadeLojas --;
           return true;
        }
    }
  return false;
}


public int quantidadeLojasPorTipo (String tipo) {
    if(lojas == null || quantidadeLojas == 0) {
        return 0;
    }
    int total = 0;
    
    switch (tipo.toLowerCase()) {
        case "cosmético":
            for(Loja loja : lojas){
                if(loja != null && loja instanceof Cosmetico) {
                    total ++;
                }
            }
            return total;
        
        case "vestuário":
            for(Loja loja : lojas){
                if(loja != null && loja instanceof Vestuario) {
                    total ++;
                }
            }
            return total;
            
        case "bijuteria":
            for(Loja loja: lojas){
                if(loja != null && loja instanceof Bijuteria) {
                    total++;
                }
            }
            return total;
            
        case "alimentação":
            for(Loja loja : lojas){
                if(loja != null && loja instanceof Alimentacao) {
                    total ++;
                }
            }
            return total;
            
        case "informática":
            for(Loja loja : lojas){
                if(loja != null && loja instanceof Informatica){
                    total++;
                }
            }
            return total;
        default:
            return -1;
    }
}

public Informatica lojaSeguroMaisCaro (){
    if(lojas == null) return null;
    
    Informatica lojaSeguroMaisCaro = null;
    double maiorSeguro = 0;
    
    for(Loja loja : lojas){
        if(loja instanceof Informatica){
            Informatica info = (Informatica) loja;
            if(info.getSeguroEletronicos() > maiorSeguro) {
                maiorSeguro = info.getSeguroEletronicos();
                lojaSeguroMaisCaro = info;
            }
        }
    }
    return lojaSeguroMaisCaro;
}
}

    
