import java.util.Scanner;

public class Principal {
    public static void main (String [] args) {
        Scanner scan = new Scanner(System.in);
        
        Loja loja1 = cadastrarLoja(scan);
        
        Produto produto1 = cadastrarProduto(scan);
        
        int opcao = -1;
        while (opcao !=3) {
            System.out.println("***MENU***");
            System.out.println("(1) criar um loja");
            System.out.println("(2) criar um produto");
            System.out.println("(3) sair");
            System.out.print("Escolha uma opção: ");
            opcao = scan.nextInt();
            
            switch (opcao) {
                case 1:
                    cadastrarLoja (scan);
                    break;
                case 2:
                    cadastrarProduto (scan);
                    break;
                case 3:
                    System.out.println("Encerrando programa...");
                    break;
                default:
                    System.out.println("Opção inválida!");
        
            }
        }
        //Está vencido
        if (loja1 != null && produto1 != null){
            Data dataReferencia = new Data (20, 10, 2023);
            
            if (produto1.estaVencido(dataReferencia)){
                System.out.println("PRODUTO VENCIDO");
            }else{
                System.out.println("PRODUTO NÃO VENCIDO");
            }
        }
        
    }
    public static Loja cadastrarLoja (Scanner scan){
        scan.nextLine();
        
        System.out.println("Nome da loja: ");
        String nome = scan.nextLine();
        
        System.out.println("Quantidade de funcionários: ");
        int quantidadeFuncionarios = scan.nextInt();
        scan.nextLine();
        
        System.out.println("Salário base dos funcionários: ");
        double salarioBaseFuncionario = scan.nextDouble();
        scan.nextLine();
        
        //Endereço
        System.out.println("****Endereço****");
        
        System.out.println("Rua: ");
        String nomeDaRua = scan.nextLine();
        
        System.out.println("Cidade: ");
        String cidade = scan.nextLine();
        
        System.out.println("Estado: ");
        String estado = scan.nextLine();
        
        System.out.println("País :");
        String pais = scan.nextLine();
        
        System.out.println("CEP :");
        String cep = scan.nextLine();
        
        System.out.println("Número :");
        String numero = scan.nextLine();
        
        System.out.println("Complemento :");
        String complemento = scan.nextLine();
        
        Endereco endereco = new Endereco (nomeDaRua, numero, cep, cidade, estado, pais, complemento);
        
        //Data
        System.out.println("Data da fundação");
        
        System.out.println("Dia: ");
        int dia = scan.nextInt();
        
        System.out.println("Mês :");
        int mes = scan.nextInt();
        
        System.out.println("Ano :");
        int ano = scan.nextInt();
        
        Data dataFundacao = new Data (dia, mes, ano);
        
        //Loja
        
        Loja loja = new Loja (nome, quantidadeFuncionarios, salarioBaseFuncionario, endereco, dataFundacao, 0);
        return loja;
    }
    
    public static Produto cadastrarProduto (Scanner scan){
        scan.nextLine();
        
        System.out.println("Nome do Produto: ");
        String nome = scan.nextLine();
        
        System.out.println("Preço: ");
        double preco = scan.nextDouble();
        scan.nextLine();
        
        //Data
        System.out.println("Data de Validade: ");
        
        System.out.println("Dia: ");
        int dia = scan.nextInt();
        
        System.out.println("Mês: ");
        int mes = scan.nextInt();
        
        System.out.println("Ano: ");
        int ano = scan.nextInt();
        
        Data dataDeValidade = new Data (dia, mes, ano);
        
        //Produto
        Produto produto = new Produto (nome, preco, dataDeValidade);
        return produto;    
    }
}