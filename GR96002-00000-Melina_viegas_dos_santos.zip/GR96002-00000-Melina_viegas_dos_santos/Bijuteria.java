public class Bijuteria extends Loja {
    private double metaVendas;
    
public Bijuteria ( String nome, int quantidadeFuncionarios, double salarioBaseFuncionario, Endereco endereco, Data dataFundacao, double metaVendas, int quantidadeMaxima) {
    super(nome, quantidadeFuncionarios, salarioBaseFuncionario, endereco, dataFundacao, quantidadeMaxima);
    this.metaVendas = metaVendas;
}

public double getMetaVendas () {
    return metaVendas;
}

public void setMetaVendas (double metaVendas) {
    this.metaVendas = metaVendas;
}

public String toString() {
    return "Loja{:Nome"+getNome()+
           "\nQuantidade de Funcionários:"+getQuantidadeFuncionarios()+
           "\nSalário Base:"+getSalarioBaseFuncionario()+
           "\nEndereço:"+getEndereco()+
           "\nData da Fundação:"+getDataFundacao()+
           "\nMeta de vendas:"+metaVendas+"}";
}
}