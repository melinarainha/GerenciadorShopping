public class Vestuario extends Loja {
    private boolean produtosImportados;

public Vestuario (String nome, int quantidadeFuncionarios, double salarioBaseFuncionario, Endereco endereco, Data dataFundacao, boolean produtoImportado,int quantidadeMaxima) {
    super(nome, quantidadeFuncionarios, salarioBaseFuncionario, endereco, dataFundacao, quantidadeMaxima);
    this.produtosImportados = produtosImportados;
}

public boolean getProdutosImportados () {
    return produtosImportados;
}

public void setProdutosImportados (boolean produtosImportados) {
    this.produtosImportados = produtosImportados;
}
    
public String toString() {
    return "Loja{:Nome"+getNome()+
           "\nQuantidade de Funcionários:"+getQuantidadeFuncionarios()+
           "\nSalário Base:"+getSalarioBaseFuncionario()+
           "\nEndereço:"+getEndereco()+
           "\nData da Fundação:"+getDataFundacao()+
           "\nProduto é importado:"+produtosImportados+"}";
}
}